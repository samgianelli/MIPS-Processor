#define STR_SIZE 256
#define NUM_THREAD 16
#define BLOCK_SIZE 16
#define GPU
#define TIMER
//#define OUTPUT

