#define BLOCK_SIZE 16
//#define TRACE

