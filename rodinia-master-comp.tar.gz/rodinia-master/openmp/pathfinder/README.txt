To compile:
make

To execute:

pathfiner width number_of_steps
typical command: ./pathfinder 100000 100 > out
